export default function Home() {
  return (
    <main style={{ padding: 24 }}>
      <h1>Starter FichaClin</h1>
      <p>API de saúde em /api/health</p>
    </main>
  );
}
