/* api.ts: não encontrado ou sem acesso */
