/* api.test.ts: não encontrado ou sem acesso */
