/* App.tsx: não encontrado ou sem acesso */
